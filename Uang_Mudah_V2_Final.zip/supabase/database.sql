create table users (
  id bigint generated always as identity primary key,
  nama_nasabah text unique not null,
  nomor_va text not null,
  nominal_tagihan bigint not null,
  limit_pinjaman bigint not null,
  status_pembayaran text default 'Belum Dibayar',
  bukti_pembayaran text,
  created_at timestamp default now()
);

create table system_config (
  id int primary key,
  sistem_aktif boolean default false,
  pin_admin text default '061223'
);
