import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ADMIN_PIN = process.env.ADMIN_PIN || '246810';

const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_SERVICE_ROLE_KEY,
  {
    db: {
      schema: 'public'
    }
  }
);

const DEFAULT_SETTINGS = {
  paymentNominal: 'Rp. 1.600.000',
  loanLimit: 'Rp 3.000.000',
  va: {
    BRI: '',
    Permata: '',
    Danamon: '',
    Mandiri: ''
  }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}

function cleanPhone(v = '') {
  return String(v).replace(/\D/g, '');
}

function mergeSettings(src = {}) {
  return {
    paymentNominal:
      src.paymentNominal || DEFAULT_SETTINGS.paymentNominal,

    loanLimit:
      src.loanLimit || DEFAULT_SETTINGS.loanLimit,

    va: {
      ...DEFAULT_SETTINGS.va,
      ...(src.va || {})
    }
  };
}

function rowToUser(row) {
  if (!row) return null;

  return {
    id: row.id,
    nama: row.nama || '',
    nohp: row.nohp || row.phone || '',
    phone: row.phone || '',
    customerNumber: row.customer_number || '',
    va: row.va || '',
    settings: mergeSettings(row.settings || {}),
    hasCustomSettings: Boolean(row.has_custom_settings),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

async function getSystemSettings() {
  const { data, error } = await supabase
    .from('system_settings')
    .select('*')
    .order('id', { ascending: true })
    .limit(1)
    .maybeSingle();

  if (error) throw error;

  if (!data) {
    const { data: created, error: createError } = await supabase
      .from('system_settings')
      .insert({
        system_active: false,
        nominal: 0,
        loan_limit: 3000000,
        va_bri: null,
        va_permata: null,
        va_danamon: null,
        va_mandiri: null
      })
      .select()
      .single();

    if (createError) throw createError;
    return created;
  }

  return data;
}

function dbSettings(row) {
  return mergeSettings({
    paymentNominal:
      row.nominal
        ? `Rp. ${Number(row.nominal).toLocaleString('id-ID')}`
        : DEFAULT_SETTINGS.paymentNominal,

    loanLimit:
      row.loan_limit
        ? `Rp ${Number(row.loan_limit).toLocaleString('id-ID')}`
        : DEFAULT_SETTINGS.loanLimit,

    va: {
      BRI: row.va_bri || '',
      Permata: row.va_permata || '',
      Danamon: row.va_danamon || '',
      Mandiri: row.va_mandiri || ''
    }
  });
}

function parseMoney(value) {
  const number = String(value || '').replace(/\D/g, '');
  return Number(number || 0);
}

async function saveSystemSettings(settings, systemActive) {
  const current = await getSystemSettings();
  const merged = mergeSettings(settings || {});

  const payload = {
    nominal: parseMoney(merged.paymentNominal),
    loan_limit: parseMoney(merged.loanLimit),
    va_bri: merged.va.BRI || null,
    va_permata: merged.va.Permata || null,
    va_danamon: merged.va.Danamon || null,
    va_mandiri: merged.va.Mandiri || null,
    updated_at: new Date().toISOString()
  };

  if (typeof systemActive === 'boolean') {
    payload.system_active = systemActive;
  }

  const { data, error } = await supabase
    .from('system_settings')
    .update(payload)
    .eq('id', current.id)
    .select()
    .single();

  if (error) throw error;

  return data;
}

export default async (req) => {
  try {
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return json({
        ok: false,
        error: 'Konfigurasi Supabase di Netlify belum lengkap'
      }, 500);
    }

    const url = new URL(req.url);

    // =========================
    // GET
    // =========================
    if (req.method === 'GET') {
      const phone = cleanPhone(
        url.searchParams.get('phone') || ''
      );

      const system = await getSystemSettings();

      if (phone) {
        const { data: user, error } = await supabase
          .from('users')
          .select('*')
          .eq('phone', phone)
          .maybeSingle();

        if (error) throw error;

        return json({
          ok: true,
          systemActive: Boolean(system.system_active),
          defaults: dbSettings(system),
          user: rowToUser(user)
        });
      }

      return json({
        ok: true,
        systemActive: Boolean(system.system_active),
        defaults: dbSettings(system)
      });
    }

    if (req.method !== 'POST') {
      return json({
        ok: false,
        error: 'Method not allowed'
      }, 405);
    }

    const body = await req.json().catch(() => ({}));
    const action = body.action;

    // =========================
    // ADMIN CHECK
    // =========================
    function checkAdmin() {
      return String(body.pin || '') === String(ADMIN_PIN);
    }

    // =========================
    // UPSERT USER
    // =========================
    if (action === 'upsert-user') {
      const phone = cleanPhone(body.phone);

      if (phone.length < 10) {
        return json({
          ok: false,
          error: 'Nomor HP tidak valid'
        }, 400);
      }

      const system = await getSystemSettings();

      // Pengguna baru tidak boleh login sebelum sistem aktif
      if (!system.system_active) {
        return json({
          ok: false,
          error: 'Sistem belum diaktifkan oleh admin',
          systemActive: false
        }, 403);
      }

      const { data: old, error: findError } = await supabase
        .from('users')
        .select('*')
        .eq('phone', phone)
        .maybeSingle();

      if (findError) throw findError;

      const oldUser = old || {};

      const user = {
        phone,
        nama: String(
          body.nama || oldUser.nama || ''
        ).trim(),

        nohp: String(
          body.nohp || oldUser.nohp || phone
        ).trim(),

        customer_number:
          oldUser.customer_number ||
          `UP-${phone.slice(-8).padStart(8, '0')}`,

        va:
          oldUser.va ||
          ('8808' + phone.slice(-10).padStart(10, '0')),

        settings:
          oldUser.settings ||
          dbSettings(system),

        has_custom_settings:
          Boolean(oldUser.has_custom_settings),

        updated_at: new Date().toISOString()
      };

      const { data: saved, error: saveError } = await supabase
        .from('users')
        .upsert(user, {
          onConflict: 'phone'
        })
        .select()
        .single();

      if (saveError) throw saveError;

      return json({
        ok: true,
        systemActive: Boolean(system.system_active),
        user: rowToUser(saved),
        defaults: dbSettings(system)
      });
    }

    // =========================
    // SAVE DEFAULTS + ACTIVATE
    // =========================
    if (action === 'save-defaults') {
      if (!checkAdmin()) {
        return json({
          ok: false,
          error: 'PIN Admin salah'
        }, 403);
      }

      const systemActive =
        typeof body.systemActive === 'boolean'
          ? body.systemActive
          : undefined;

      const saved = await saveSystemSettings(
        body.settings || {},
        systemActive
      );

      return json({
        ok: true,
        systemActive: Boolean(saved.system_active),
        settings: dbSettings(saved)
      });
    }

    // =========================
    // SAVE USER
    // =========================
    if (action === 'save-user') {
      if (!checkAdmin()) {
        return json({
          ok: false,
          error: 'PIN Admin salah'
        }, 403);
      }

      const phone = cleanPhone(body.phone);

      if (phone.length < 10) {
        return json({
          ok: false,
          error: 'Nomor HP tidak valid'
        }, 400);
      }

      const { data: old, error: findError } = await supabase
        .from('users')
        .select('*')
        .eq('phone', phone)
        .maybeSingle();

      if (findError) throw findError;

      if (!old) {
        return json({
          ok: false,
          error: 'Pengguna tidak ditemukan'
        }, 404);
      }

      const { data: saved, error: saveError } = await supabase
        .from('users')
        .update({
          settings: mergeSettings(body.settings || {}),
          has_custom_settings: true,
          updated_at: new Date().toISOString()
        })
        .eq('phone', phone)
        .select()
        .single();

      if (saveError) throw saveError;

      return json({
        ok: true,
        user: rowToUser(saved)
      });
    }

    // =========================
    // LIST USERS
    // =========================
    if (action === 'list-users') {
      if (!checkAdmin()) {
        return json({
          ok: false,
          error: 'PIN Admin salah'
        }, 403);
      }

      const { data: users, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', {
          ascending: false
        });

      if (error) throw error;

      return json({
        ok: true,
        users: (users || []).map(rowToUser)
      });
    }

    return json({
      ok: false,
      error: 'Action tidak dikenal'
    }, 400);

  } catch (e) {
    console.error(e);

    return json({
      ok: false,
      error: 'Server error',
      detail: e.message
    }, 500);
  }
};
