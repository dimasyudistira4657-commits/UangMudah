UANG MUDAH V2 FINAL

Nama Aplikasi : Uang Mudah
PIN Admin      : 061223

FITUR
- Login Admin dengan PIN 061223.
- Menu Admin tersembunyi.
- Login Nasabah menggunakan Nama Nasabah.
- Tambah/Edit Nasabah.
- Nomor VA, Nominal Tagihan, Limit Pinjaman.
- Aktifkan / Nonaktifkan Sistem.
- Status Pembayaran:
  Belum Dibayar -> Menunggu Konfirmasi -> Lunas.
- Siap dihubungkan ke Supabase dan dibungkus menjadi APK Android.
